sap.ui.define(["sap/ui/core/mvc/Controller"],function(n){"use strict";return n.extend("sap.btp.helloworldui5.controller.App",{onInit:function(){}})});
//# sourceMappingURL=App.controller.js.map