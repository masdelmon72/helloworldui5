sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("sap.btp.helloworldui5.controller.App", {
        onInit: function() {
        }
      });
    }
  );
  